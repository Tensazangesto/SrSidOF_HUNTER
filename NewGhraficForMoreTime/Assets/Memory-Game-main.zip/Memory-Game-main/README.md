# Memory Game
Memory Game using Flet Framework Python

#### Install flet framework using pip:

<code>pip install flet</code>

Screenshot:

![Screenshot1](Screenshot1.png)

![Screenshot2](Screenshot2.png)
